package controls;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import pages.WebPage;
import utils.Events;

public class DateControl {
	private WebElement dateControl;
	private By by;
	
	public DateControl(WebElement date, String desc) {
		dateControl = date;
		WebPage.elementList.put(dateControl, desc);
	}
	
	/**
	 * Constructor for DateControl when By of the DateControl is required
	 * @author PSubramani33
	 * @param date
	 * @param byOfDateControl
	 * @param desc
	 */
	public DateControl(WebElement date,By byOfDateControl, String desc) {
		dateControl = date;
		by=byOfDateControl;
		WebPage.elementList.put(dateControl, desc);
	}
	
	/**
	 * This method will select a date in Date controls
	 * 
	 * @author PSubramani33
	 * @throws IOException
	 */
	public void click() throws IOException {
		Events.click(WebPage.driver, dateControl);
	}
	/**
	 * This method will return By of the dateControl
	 * @author PSubramani33
	 * @return
	 */
	public By getBy(){
		return by;
	}
	
	/**
	 * This method will return the webelement for date control
	 * @author PSubramani33
	 * @return
	 */
	public WebElement getWebElement(){
		return dateControl;
	}
}
