package controls;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import pages.WebPage;

public class Label {
	private By by;
	private WebElement lbl;
	
	/**
	 * Normal constructor
	 * @author PSubramani33
	 * @param label
	 * @param desc
	 */
	public Label(WebElement label, String desc) {
		lbl = label;
		WebPage.elementList.put(lbl, desc);
	}
	
	/**
	 * Constructor for Label when By of the label is required
	 * @author PSubramani33
	 * @param label
	 * @param byOfLabel
	 * @param desc
	 */
	public Label(WebElement label,By byOfLabel, String desc) {
		lbl = label;
		by=byOfLabel;
		WebPage.elementList.put(lbl, desc);
	}

	/**
	 * This method will return the content in the Label
	 * 
	 * @author PSubramani33
	 * @return
	 */
	public String getText() {
		return lbl.getText();
	}
	
	/**
	 * This method will return the By of the label
	 * @author PSubramani33
	 * @return
	 */
	public By getBy() {
		return by;
	}
	
	/**
	 * This method will return the webElement of the label
	 * @author PSubramani33
	 * @return 
	 */
	public WebElement getWebElement() {
		return lbl;
	}
}
