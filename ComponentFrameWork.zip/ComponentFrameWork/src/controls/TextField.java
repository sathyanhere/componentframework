package controls;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import pages.WebPage;
import utils.Events;

public class TextField {
	
	private WebElement textField;
	private By by;
	String txtDescription;
	
	/**
	 * This method will return the By of the text field
	 * @author PSubramani33
	 * @return
	 */
	public By getBy(){
		return by;
	}
	
	/**
	 * This method will return the webElement of the text field
	 * @author PSubramani33
	 * @return 
	 */
	public WebElement getWebElement(){
		return textField;
	}
	
	/**
	 * Normal Constructor for Text field
	 * @author PSubramani33
	 * @param txtField
	 * @param desc
	 */
	public TextField(WebElement txtField, String desc) {
		textField = txtField;
		WebPage.elementList.put(textField, desc);
	}
	/**
	 * Constructor for text field when By of the text field is required
	 * @author PSubramani33
	 * @param txtField
	 * @param by
	 * @param desc
	 */
	public TextField(WebElement txtField, By byOfTextField, String desc) {
		by=byOfTextField;
		textField = txtField;
		WebPage.elementList.put(textField, desc);
	}

	/**
	 * This method will type the text in Text Field
	 * 
	 * @author PSubramani33
	 * @param text
	 * @throws IOException
	 */
	public void type(String text) throws IOException {
		Events.type(WebPage.driver, textField, text);
	}
	
	/**
	 * This method will click in the Text Field for Date controls
	 * 
	 * @author PSubramani33
	 * @throws IOException
	 */
	public void click() throws IOException {
		Events.click(WebPage.driver, textField);
	}
	
	/**
	 * This method will return the text in the text field
	 * 
	 * @author PSubramani33
	 * @return
	 */
	public String getText(){
		return textField.getText();	
	}
	
}
