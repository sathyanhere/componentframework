package controls;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import pages.WebPage;
import utils.Events;

public class Link {
	private WebElement link;
	private By by;
	
	String linkName;

	
	/**
	 * Constructor for Link when By of the link is required
	 * @author PSubramani33
	 * @param linkText
	 * @param byOfLink
	 * @param desc
	 */
	public Link(WebElement linkText,By byOfLink, String desc) {
		link = linkText;
		by=byOfLink;
		WebPage.elementList.put(link, desc);
	}
	public Link(WebElement linkText, String desc) {
		link = linkText;
		WebPage.elementList.put(link, desc);
	}

	public Link(String text){
		link=WebPage.driver.findElement(By.linkText(text));
		WebPage.elementList.put(link, text);
	}
	
	/**
	 * This method will click in the link passed as argument
	 * 
	 * @author PSubramani33
	 * @throws IOException
	 */
	public void click() throws IOException {
		Events.click(WebPage.driver, link);
	}
	
	/**
	 * This method will return whether the Link is visible in the page
	 * @return boolwn 
	 * @throws IOException
	 */
	public boolean isVisible() throws IOException {
		return link.isDisplayed();
	}
	
	/**
	 * This method will return the By for the button
	 * @author PSubramani33
	 * @param elem
	 * @return
	 */
	public By getBy() {
		return by;
	}
	
	/**
	 * This method will return the text displayed in the text
	 * 
	 * @author PSubramani33
	 * @return
	 */
	public String getText(){
		return link.getText();
	}
	/**
	 * This method will return the webelement of the link
	 * @author PSubramani33
	 * @return
	 */
	public WebElement getWebElement(){
		return link;
	}
}
