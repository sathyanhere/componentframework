package controls;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import pages.WebPage;
import utils.Events;

public class CheckBox {
	private WebElement checkBox;
	private By by;
	
	
	public CheckBox(WebElement checkBoxName, String description) {
		checkBox = checkBoxName;
		WebPage.elementList.put(checkBox, description);
	}
	/**
	 * Constructor for Check Box when By of the check box is required
	 * @author PSubramani33
	 * @param checkBoxName
	 * @param byOfCheckBox
	 * @param description
	 */
	public CheckBox(WebElement checkBoxName,By byOfCheckBox, String description) {
		checkBox = checkBoxName;
		by=byOfCheckBox;
		WebPage.elementList.put(checkBox, description);
	}
	
	/**
	 * This method will check the check box if it is unchecked
	 * 
	 * @author PSubramani33
	 * @throws IOException
	 */
	public void check() throws IOException {
		Events.check(WebPage.driver, checkBox);

	}

	/**
	 * this method will uncheck the check box if it is checked, leaves it if the
	 * check box is not checked
	 * 
	 * @author PSubramani33
	 * @throws IOException
	 */
	public void unCheck() throws IOException {
		Events.unCheck(WebPage.driver, checkBox);
	}
	
	/**
	 * This method will return whether the Check box is visible in the page 
	 * @throws IOException
	 */
	public boolean isVisible() throws IOException {
		return checkBox.isDisplayed();
	}
	
	/**
	 * This method will return whether the Check box is checked in the page 
	 * @throws IOException
	 */
	public boolean isChecked() throws IOException {
		return checkBox.isSelected();
	}
	
	
	/**
	 * This method will return the By for the Check Box
	 * @author PSubramani33
	 * @param elem
	 * @return
	 */
	public By getBy() {
		return by;
	}
	
	/**
	 * This method will return the webelement of the check box
	 * 
	 * @author PSubramani33
	 * @return
	 */
	public WebElement getWebElement(){
		return checkBox;
	}
}
