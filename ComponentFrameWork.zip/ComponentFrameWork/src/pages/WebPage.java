package pages;

import java.util.HashMap;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import reports.Report;
import controls.Button;
import controls.CheckBox;
import controls.DateControl;
import controls.Label;
import controls.Link;
import controls.SelectBox;
import controls.TextArea;
import controls.TextField;

public class WebPage {
	/**
	 * elementList is a map which contains component and its description, this map is utilized in report generation for writing the details of the 
	 * actions performed of the web elements
	 * 
	 */
	public static HashMap<Object, String> elementList = new HashMap<Object, String>();
	public static String PAGE_URL = "";
	
	public static WebDriver driver = new FirefoxDriver();
	
	/**
	 * Constructor method, initialize webdriver instance, initialize page URL
	 * and open the URL in web browser. This constructor is used for the first
	 * page in the application
	 * 
	 * @author pssubramanian
	 * @param webDriver
	 * @param pageURL
	 */
	public WebPage(WebDriver webDriver, String pageURL) {
		driver = webDriver;
		PAGE_URL = pageURL;
		webDriver.get(PAGE_URL);
		
	}
	
	

	/**
	 * Constructor initialize the webdriver used for the pages coming after the
	 * first page in application
	 * 
	 * @author pssubramanian
	 * @param webDriver
	 */
	public WebPage(WebDriver webDriver) {
		driver = webDriver;
		webDriver.get(PAGE_URL);
	}
	
	/**
	 * Constructor, opens the page with passed URL
	 * @param PageURL
	 */
	public WebPage(String PageURL) {
		driver.get(PageURL);
	}
	
	/**
	 * Default Constructor
	 */
	public WebPage() {
	}
	
	/**
	 * This constructor will convert the URL to respective environment configured in testNG XML
	 * 
	 * @author PSubramani33
	 * @param PageURL
	 * @param env
	 */
	public WebPage(String PageURL, String env) {
		if(PageURL.contains("dev")){
			PageURL=PageURL.replaceAll("dev", env);
		}
		if(PageURL.contains("test")){
			PageURL=PageURL.replaceAll("test", env);
		}
		if(PageURL.contains("stage")){
			PageURL=PageURL.replaceAll("stage", env);
		}
		driver.get(PageURL);
	}

	/**
	 * This method will wait for the element specified for 60 seconds 
	 * @author pssubramanian
	 * @param by
	 * 
	 */
	public void waitForElementPresent(By by) {
		
		Report.log("Waiting for the element to load " + by.toString());
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}
	
	/**
	 * /**
	 * This method will wait for the element specifed for specified time
	 * 
	 * @author pssubramanian
	 * @param by
	 * @param timeToWait
	 * 
	 */
	public void waitForElementPresent(By by, long timeToWait) {
		Report.log("Waiting for the element to load " + by.toString());
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(by));

	}
	
	/**
	 * This method will wait for TextField for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForTextField(TextField tf){
		Report.log("Waiting for the element to load " + elementList.get(tf));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(tf.getBy()));
	}
	
	/**
	 * This method will wait for TextArea for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForTextArea(TextArea ta) {
		Report.log("Waiting for the element to load " + elementList.get(ta));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(ta.getBy()));
	}
	
	/**
	 * This method will wait for Button for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForButton(Button button) {
		Report.log("Waiting for the element to load " + elementList.get(button));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(button.getBy()));
	}
	
	/**
	 * This method will wait for Label for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForLabel(Label label) {
		Report.log("Waiting for the element to load " + elementList.get(label));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(label.getBy()));
	}
	
	/**
	 * This method will wait for Check Box for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForCheckBox(CheckBox check) {
		Report.log("Waiting for the element to load " + elementList.get(check));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(check.getBy()));
	}
	
	/**
	 * This method will wait for Date Control for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForDateControl(DateControl date) {
		Report.log("Waiting for the element to load " + elementList.get(date));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(date.getBy()));
	}
	
	
	/**
	 * This method will wait for Link for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForLink(Link link) {
		Report.log("Waiting for the element to load " + elementList.get(link));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(link.getBy()));
	}
	
	
	/**
	 * This method will wait for SelectBox for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForSelect(SelectBox select) {
		Report.log("Waiting for the element to load " + elementList.get(select));
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.presenceOfElementLocated(select.getBy()));
	}
	
	
	/**
	 * This method will wait for TextField for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForTextField(TextField tf,Long timeToWait){
		Report.log("Waiting for the element to load " + elementList.get(tf));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(tf.getBy()));
	}
	
	/**
	 * This method will wait for TextArea for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForTextArea(TextArea ta,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(ta));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(ta.getBy()));
	}
	
	/**
	 * This method will wait for Button for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForButton(Button button,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(button));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(button.getBy()));
	}
	
	/**
	 * This method will wait for Label for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForLabel(Label label,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(label));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(label.getBy()));
	}
	
	/**
	 * This method will wait for Check Box for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForCheckBox(CheckBox check,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(check));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(check.getBy()));
	}
	
	/**
	 * This method will wait for Date Control for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForDateControl(DateControl date,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(date));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(date.getBy()));
	}
	
	
	/**
	 * This method will wait for Link for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForLink(Link link,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(link));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(link.getBy()));
	}
	
	
	/**
	 * This method will wait for SelectBox for 60 seconds 
	 * @author PSubramani33
	 */
	public void waitForSelect(SelectBox select,Long timeToWait) {
		Report.log("Waiting for the element to load " + elementList.get(select));
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		wait.until(ExpectedConditions.presenceOfElementLocated(select.getBy()));
	}
	
	/**
	 * This method will accept the alert thrown in the page and return the control to the page
	 * @author PSubramani33
	 */
	public void acceptAlert() {
		Alert alert = driver.switchTo().alert();
		alert.accept();
		driver.switchTo().defaultContent();
	}
	
	/**
	 * This method will dismiss the alert and return the control to the page
	 * @author PSubramani33
	 */
	public void cancelConfirmation() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
		driver.switchTo().defaultContent();
	}
	
	/**
	 * verify the presence of passed text
	 * @author PSubramani33
	 * @param text
	 * @return
	 */
	public static boolean isTextPresent(String text) {
		WebElement body = driver.findElement(By.tagName("body"));
		boolean isTextPresent = body.getText().contains(text);
		if (isTextPresent) {
			Report.log("The Text " + text + " is present <BR>");
		} else {
			Report.log("The Text " + text + " is not present <BR>");
		}
		return isTextPresent;
	}
	
	/**
	 * Gets the label of passed WebElement
	 * @author PSubramani33
	 * @param webElement
	 * @return
	 */
	public String StoreTextPresent(WebElement webElement) {
		return webElement.getText();
	}
	
	/**
	 * wait for text to present in the page
	 * @author PSubramani33
	 * @param text
	 * @throws Exception 
	 */
	public void waitForTextPresent(String text) throws Exception {
		Assert.assertNotNull(text, "Text can't be null");
		Report.log("waitForTextPresent " + text + "<BR>");
		boolean textPresent = false;
		for (int sec = 1; sec < 60; sec += 1) {
			if ((isTextPresent(text))) {
				textPresent = true;
			}
		}
		Report.log("The passed Text is not present in the page");
		throw new Exception("Text is not available in the page");
	}
	
	/**
	 * wait for text to disappear from the page
	 * @author PSubramani33
	 * @param text
	 * @throws Exception
	 */
	public void waitForTextToDisappear(String text)throws Exception  {
		Assert.assertNotNull(text, "Text can't be null");
		Report.log("waitForTextToDisappear " + text + "<BR>");
		boolean textPresent = true;
		for (int sec = 0; sec < 60; sec += 1) {
			if (!(isTextPresent(text))) {
				textPresent = false;
				break;
			}
		}
		Report.log("The passed Text does not disappear from the page");
		throw new Exception("The passed Text does not disappear from the page");
	}
	
	/**
	 * verifies the text present in the page
	 * @author PSubramani33
	 * @param text
	 */
	public void assertTextPresent(String text) {
		Assert.assertNotNull(text, "Text can't be null");
		Report.log("Assert Text Present ");
		Assert.assertTrue(isTextPresent(text));
	}
	
	/**
	 * verifies the Text not present in the page
	 * 
	 * @author PSubramani33
	 * @param text
	 */
	public void assertTextNotPresent(String text) {
		Assert.assertNotNull(text, "Text can't be null");
		Report.log("Assert Text not Present ");
		Assert.assertFalse(isTextPresent(text));
	}
	
	/**
	 * this method will verify whether the webelement is available in the page
	 * @author PSubramani33
	 * @param by
	 * @return
	 */
	public boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }
	 
	/**
	 * @author PSubramani33
	 * @param expected
	 * @param actual
	 */
	public void assertEquals(String expected, String actual){
		Report.log("Comparing two strings "+ expected +" and "+actual);
		Assert.assertEquals(expected, actual);
		Report.log(" Comparision result passed <BR>");
	}
	
}