package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.EventDTO;

public class dao {
	public static Connection conn=null;
	private static Connection getConnection() throws ClassNotFoundException,
			SQLException {
		Class.forName("com.ibm.db2.jcc.DB2Driver");
		conn = DriverManager.getConnection(
				"jdbc:db2://ecmdbt02.shaklee.com:60004/shaklee1", "icshktst",
				"test123");
		return conn;
	}
	public static void closeConnection() throws SQLException {
		conn.close();
	}
	
	/**
	 * This method will return the Last Name and First name for the shaklee ID passed
	 * @author PSubramani33
	 * @param customerID
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static String getCustomerName(String customerID)
			throws ClassNotFoundException, SQLException {
		conn = dao.getConnection();
		String customerName = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("select concat(concat(first_name, ' '), last_name) from EXT_USER where user_login_id = ?");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				customerName = rset.getString(1);
			}
		}
		dao.closeConnection();
		return customerName;
	}
	
	/**
	 * This method will return the first name of the shaklee ID passed
	 * @param customerID
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static String getCustomerFirstName(String customerID)
			throws ClassNotFoundException, SQLException {
		conn = dao.getConnection();
		String customerName = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("select first_name from EXT_USER where user_login_id = ?");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				customerName = rset.getString(1);
			}
		}
		dao.closeConnection();
		return customerName;
	}
	
	/**
	 * This method will say whether the passed shaklee ID can publish global events or not
	 * @param customerID
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static String canPublishShakleeEvents(String customerID)
			throws ClassNotFoundException, SQLException {
		conn = dao.getConnection();
		String canPublishGlobalEvent = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("select is_revoked from GOVERN_GLOBAL_EVENTS where dist_id = ?");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				canPublishGlobalEvent = rset.getString(1);
			}
		}
		dao.closeConnection();
		if (canPublishGlobalEvent.equals("Y"))
			return "NO";
		else
			return "YES";
	}
	
	/**
	 * This method will return the no of events removed by admin for the shaklee ID passed
	 * @param customerID
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static String eventsRemoved(String customerID)
	throws ClassNotFoundException, SQLException {
		String eventsRemoved=null;
		conn = dao.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("SELECT COUNT(*) as revokedcnt FROM IK_CALENDAR_EVENTS WHERE OWNER_ID = ? AND GLOBAL_EVENT_REVOKED_TSTAMP IS NOT NULL ");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				eventsRemoved = rset.getString(1);
			}
		}
		dao.closeConnection();
		return eventsRemoved;
	}
	
	/**
	 * This method will return the event Name and 
	 * @param customerID
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static ArrayList<EventDTO> getEventsNameAndDate(String customerID)
			throws ClassNotFoundException, SQLException {
		ArrayList<EventDTO> eventDetails = new ArrayList<EventDTO>();
		EventDTO dto;
		conn = dao.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn.prepareStatement("select iee.subject , iee.evite_date from ik_evites iee , ik_event_evites ee where ee.evite_id=iee.id and ee.event_id in (select e.event_id from  ik_calendar_events E where e.owner_id= ? and e.is_published_global = 'Y') order by evite_date ");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				dto=new EventDTO();
				dto.setEventName(rset.getString(1));
				String dbDate=rset.getString(2);
				String year=dbDate.substring(0, 4);
				String month=dbDate.substring(5, 8);
				String day=dbDate.substring(8, 10)+"-";
				String date=month+day+year;
				date=date.replaceAll("-", "/");
				dto.setEventDate(date);
				eventDetails.add(dto);
			}
		}
		dao.closeConnection();
		return eventDetails;
	}
	
	public static String getFirstEventName(String customerID)
			throws ClassNotFoundException, SQLException {
		String name = null;
		conn = dao.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("select iee.subject from ik_evites iee , ik_event_evites ee where ee.evite_id=iee.id and  ee.event_id in (select e.event_id from  ik_calendar_events E where e.owner_id= ?  and e.is_published_global = 'Y') order by evite_date  FETCH FIRST 1 ROWS ONLY ");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				name = rset.getString(1);
			}
		}
		dao.closeConnection();
		return name;
	}
	
	public static String getCountryCode(String customerID)
			throws ClassNotFoundException, SQLException {
		String countryCode = null;
		conn = dao.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		pstmt = conn
				.prepareStatement("select country_code from EXT_USER where user_login_id = ?");
		pstmt.setString(1, customerID);
		rset = pstmt.executeQuery();
		if (rset != null) {
			while (rset.next()) {
				countryCode = rset.getString(1);
			}
		}
		dao.closeConnection();
		return countryCode;
	}
	
//	public 
	
}