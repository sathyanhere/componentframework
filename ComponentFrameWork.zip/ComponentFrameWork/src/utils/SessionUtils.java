package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SessionUtils {
	public static WebDriver driver;

	private SessionUtils() {

	}

	public static WebDriver getNewFireFox() {
		driver = new FirefoxDriver();
		return driver;
	}

}