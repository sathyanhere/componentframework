package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import pages.WebPage;
import reports.Report;


public class Events {
	private static WebElement element;
	private static Select select;
	private static String ScreenShotInitial="<a href=\"./";
	private static String ScreenShotEnd=".png\"> SCREEN SHOT </a> \n";
	private static Integer counter=1;
	
	/**
	 * This method will click in the webElement passed as argument 
	 * @author pssubramanian
	 * @param webElement
	 * @throws IOException 
	 */
	public static void click(WebDriver webDriver, WebElement webElement) throws IOException {
		element=webElement;
		element.click();
		write("<b>Clicking the element "+WebPage.elementList.get(element),counter++,webDriver);
	}
	
	/**
	 * This method will type the text in webElement passed as arguments
	 * @author pssubramanian
	 * @param webElement
	 * @param text
	 * @throws IOException 
	 */
	public static void type(WebDriver webDriver, WebElement webElement, String text) throws IOException {
		element=webElement;
		element.clear();
		element.sendKeys(text);
		write("<b>Typing \'"+text+"\' in "+WebPage.elementList.get(element), counter++,webDriver);
	}
	
	
	/**
	 * This method select the text in drop down for the passed index
	 * 
	 * @author pssubramanian
	 * @param webDriver
	 * @param selectField
	 * @param index
	 * @throws IOException
	 */
	public static void select(WebDriver webDriver, Select selectField,
			int index) throws IOException {
		select=selectField;
		select.selectByIndex(index);
		write("<b>Selecting the " + index + "th element in "
				+ WebPage.elementList.get(select), counter++, webDriver);
	}

	/**
	 * This method selects the text in drop down for the passed value
	 * 
	 * @author pssubramanian
	 * @param webDriver
	 * @param selectField
	 * @param value
	 * @throws IOException
	 */
	public static void selectByValue(WebDriver webDriver,Select selectField, String value) throws IOException {
		select=selectField;
		select.selectByValue(value);
		write("<b>Selecting \'" + value + "\' in "+WebPage.elementList.get(select), counter++, webDriver);
	}

	/**
	 * This method selects the passed text in the drop down
	 * 
	 * @author pssubramanian
	 * @param webDriver
	 * @param selectField
	 * @param selectString
	 * @throws IOException
	 */
	public static void selectByText(WebDriver webDriver, Select selectField,
			String selectString) throws IOException {
		select=selectField;
		select.selectByVisibleText(selectString);
		write("<b>Selecting \'" + selectString + "\' in "+ WebPage.elementList.get(select), counter++, webDriver);
	}
	
	/**
	 * This method will check the check box if it is unchecked
	 * @param webDriver
	 * @param webElement
	 * @param text
	 * @throws IOException
	 */
	public static void check(WebDriver webDriver, WebElement webElement)
			throws IOException {
		element = webElement;
		if (!element.isSelected()) { //checks whether check box is unchecked
			element.click();
		}
		write("<b>Checking \'"+ WebPage.elementList.get(webElement), counter++, webDriver);
	}
    
	
	 /**
	  * this method will uncheck the check box if it is checked, leaves it if the check 
	  * box is not checked
	  * @param webDriver
	  * @param webElement
	  * @param text
	  * @throws IOException
	  */
	public static void unCheck(WebDriver webDriver, WebElement webElement)
			throws IOException {
		element = webElement;
		if (element.isSelected()) { // checks whether check box is checked
			element.click();
		}
		write("<b>Un Checking \'"+ WebPage.elementList.get(webElement), counter++, webDriver);
	}
	
	/**
	 * This method will write trace and take screen shot and put the screen shot in the destination location and link the screen shot with the report
	 * 
	 * @author pssubramanian
	 * @param logMessage
	 * @param counter
	 * @param webDriver
	 * @throws IOException
	 */
	public static void write(String logMessage,Integer counter, WebDriver webDriver) throws IOException{
		String hyperLink=ScreenShotInitial+counter+ScreenShotEnd;
		String message=logMessage+hyperLink+"<BR>";
		Report.log(message);
		File directory = new File (".");
		String path=directory.getCanonicalPath()+"\\test-output\\";
		File f=new File(path+counter+".png");
//		File f=new File(WebPage.reportFilePath+counter+".png");
		File scrFile = ((TakesScreenshot)webDriver).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(scrFile, f);
		counter++;
	}
}
