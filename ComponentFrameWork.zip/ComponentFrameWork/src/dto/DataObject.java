package dto;

public class DataObject {
public String getQty1() {
		return qty1;
	}
	public void setQty1(String qty1) {
		this.qty1 = qty1;
	}
	public String getQty2() {
		return qty2;
	}
	public void setQty2(String qty2) {
		this.qty2 = qty2;
	}
String qty;
String qty1;
String qty2;
String itemCode;
String cardNumber;
String cardHolderName;
String cardExpMonth;
String cardExpYear;
String asFrequency;
String asShipdate;
String cardType;

public String getCardType() {
	return cardType;
}
public void setCardType(String cardType) {
	this.cardType = cardType;
}
public String getAsFrequency() {
	return asFrequency;
}
public void setAsFrequency(String asFrequency) {
	this.asFrequency = asFrequency;
}
public String getAsShipdate() {
	return asShipdate;
}
public void setAsShipdate(String asShipdate) {
	this.asShipdate = asShipdate;
}
public String getQty() {
	return qty;
}
public void setQty(String qty) {
	this.qty = qty;
}
public String getItemCode() {
	return itemCode;
}
public void setItemCode(String itemCode) {
	this.itemCode = itemCode;
}
public String getCardNumber() {
	return cardNumber;
}
public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}
public String getCardHolderName() {
	return cardHolderName;
}
public void setCardHolderName(String cardHolderName) {
	this.cardHolderName = cardHolderName;
}
public String getCardExpMonth() {
	return cardExpMonth;
}
public void setCardExpMonth(String cardExpMonth) {
	this.cardExpMonth = cardExpMonth;
}
public String getCardExpYear() {
	return cardExpYear;
}
public void setCardExpYear(String cardExpYear) {
	this.cardExpYear = cardExpYear;
}
}
