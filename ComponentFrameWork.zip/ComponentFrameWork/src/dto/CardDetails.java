package dto;

public class CardDetails {
	public String cardHolderName;
public String cardNumber;
public String cardexpm;
public String cardexpy;

public String getCardHolderName() {
	return cardHolderName;
}
public void setCardHolderName(String cardHolderName) {
	this.cardHolderName = cardHolderName;
}
public String getCardNumber() {
	return cardNumber;
}
public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}
public String getCardexpm() {
	return cardexpm;
}
public void setCardexpm(String cardexpm) {
	this.cardexpm = cardexpm;
}
public String getCardexpy() {
	return cardexpy;
}
public void setCardexpy(String cardexpy) {
	this.cardexpy = cardexpy;
}


	
}
