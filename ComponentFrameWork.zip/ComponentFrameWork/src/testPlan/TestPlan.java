package testPlan;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import pages.WebPage;

public class TestPlan {

	public String baseUrl;
	public Properties prop = new Properties();
	/**
	 * This method will create the driver instance
	 * 
	 * @author pssubramanian
	 */
	
	@BeforeSuite(groups = "TestPlan")
	public void setUp() {
		System.out.println("test plan constructor");
		WebPage.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	/**
	 * This method will assign the name of the property file where the data is stored
	 * 
	 * @author pssubramanian
	 * @param reportFilePath
	 * @throws Exception
	 */
	@Parameters(value = "dataFile")
	@BeforeTest(groups = "TestPlan")
	public void setPropertyFilePath(String dataFile) throws Exception {
		System.out.println("setting property file path");
		File directory = new File (".");
		prop.load(new FileInputStream(directory.getCanonicalPath()+"\\src\\properties\\"+dataFile));
	}
	/**
	 * This method will close the driver instance and open the report in default browser
	 * 
	 * @author pssubramanian
	 * @throws Exception
	 */
	@AfterTest(groups = "TestPlan")
	public void tearDown() throws Exception {
		System.out.println("inside tear down");
		WebPage.driver.quit();
		File directory = new File (".");
		String path=directory.getCanonicalPath()+"\\test-output\\index.html";
		File f=new File(path);
		Desktop.getDesktop().open(f);
	}

}